/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     28/06/2020 03:41:12 p. m.                    */
/*==============================================================*/


drop table if exists KARDEX;

drop table if exists MEDICAMENTO;

drop table if exists PACIENTE;

drop table if exists ADMINISTRADOR;

drop table if exists DOCTOR;

drop table if exists REPORRE_RECETA;

drop table if exists REPORTE_DE_EFERMEDADES;

drop table if exists KARDEX;

drop table if exists RESERVA;

drop table if exists USUARIO;

/*==============================================================*/
/* Table: ADMINISTRADOR                                         */
/*==============================================================*/
create table ADMINISTRADOR
(
   ID_A                 int not null,
   USUARIO_A            varchar(11),
   CONTRASENIA          varchar(11),
   primary key (ID_A)
);

/*==============================================================*/
/* Table: DOCTOR                                                */
/*==============================================================*/
create table DOCTOR
(
   ID_D                 int not null,
   NOMBRE_D             varchar(11),
   APELLIDO_D           varchar(11),
   ESPECIALIDAD         varchar(11),
   CONTRASENIA_D        varchar(11),
   USUARIO_D            varchar(11),
   TURNO                varchar(11),
   TELEFONO             int,
   GENERO_D             char(1),
   primary key (ID_D)
);

/*==============================================================*/
/* Table: KARDEX                                                */
/*==============================================================*/
create table KARDEX
(
   DIAGNOSTICO          varchar(11),
   CAMA                 varchar(11),
   GRADO                varchar(11),
   FECHA_DE_INGRESO     datetime,
   DIETA                int,
   TRATAMIENTO          text,
   ID_K                 int not null,
   ID_D                 int not null,
   ID_P                 int not null,
   PESO                 int,
   ALTURA               int,
   FECHA_N              date,
   primary key (ID_K)
);

/*==============================================================*/
/* Table: MEDICAMENTO                                           */
/*==============================================================*/
create table MEDICAMENTO
(
   NOMBRE_M             varchar(11),
   PRECIO               int,
   CANTIDAD_LETAL       varchar(11),
   TIPO_ENFERMEDAD      varchar(11),
   NO_RESETADO_PARA     varchar(11),
   CANTIDAD             int,
   ID_M                 int not null,
   ID_P                 int not null,
   ID_D                 int not null,
   primary key (ID_M)
);

/*==============================================================*/
/* Table: PACIENTE                                              */
/*==============================================================*/
create table PACIENTE
(
   ID_P                 int not null,
   NOMBRE_P             varchar(11),
   APELLIDO_P           varchar(11),
   SINTOMAS             text,
   AFILIADO             bool,
   FECHA_INGRESO        date,
   NUMEROCEL            int,
   GENERO_P             char(1),
   CI_P                 int,
   EDAD                 int,
   primary key (ID_P)
);

/*==============================================================*/
/* Table: REPORRE_RECETA                                        */
/*==============================================================*/
create table REPORRE_RECETA
(
   ID_R                 int not null,
   ID_D                 int not null,
   ID_P                 int not null,
   TEXTO                text,
   FECHA_EMISION        datetime,
   primary key (ID_R)
);

/*==============================================================*/
/* Table: REPORTE_DE_EFERMEDADES                                */
/*==============================================================*/
create table REPORTE_DE_EFERMEDADES
(
   NOMBE_F              varchar(11),
   CASOS                int,
   TIPO_CASO            varchar(11),
   ID_F                 int not null,
   ID_D                 int not null,
   CI                   varchar(11),
   RECUPERADOS          int,
   INTERNADOS           int,
   primary key (ID_F)
);

/*==============================================================*/
/* Table: RESERVA                                               */
/*==============================================================*/
create table RESERVA
(
   FECHA_RESERVA        datetime,
   ID_RP                int not null,
   ID_P                 int not null,
   ID_A                 int not null,
   ID_D                 int not null,
   primary key (ID_RP)
);

/*==============================================================*/
/* Table: USUARIO                                               */
/*==============================================================*/
create table USUARIO
(
   NOMBRE               varchar(11),
   APELLIDO             varchar(11),
   CI                   varchar(11) not null,
   primary key (CI)
);

alter table KARDEX add constraint FK_D__K foreign key (ID_D)
      references DOCTOR (ID_D) on delete restrict on update restrict;

alter table KARDEX add constraint FK_P__K foreign key (ID_P)
      references PACIENTE (ID_P) on delete restrict on update restrict;

alter table MEDICAMENTO add constraint FK_D__M foreign key (ID_D)
      references DOCTOR (ID_D) on delete restrict on update restrict;

alter table MEDICAMENTO add constraint FK_RELATIONSHIP_5 foreign key (ID_P)
      references PACIENTE (ID_P) on delete restrict on update restrict;

alter table REPORRE_RECETA add constraint FK_D__R foreign key (ID_D)
      references DOCTOR (ID_D) on delete restrict on update restrict;

alter table REPORRE_RECETA add constraint FK_P__R foreign key (ID_P)
      references PACIENTE (ID_P) on delete restrict on update restrict;

alter table REPORTE_DE_EFERMEDADES add constraint FK_D__R2 foreign key (ID_D)
      references DOCTOR (ID_D) on delete restrict on update restrict;

alter table REPORTE_DE_EFERMEDADES add constraint FK_U__R2 foreign key (CI)
      references USUARIO (CI) on delete restrict on update restrict;

alter table RESERVA add constraint FK_A__R1 foreign key (ID_A)
      references ADMINISTRADOR (ID_A) on delete restrict on update restrict;

alter table RESERVA add constraint FK_D__R1 foreign key (ID_D)
      references DOCTOR (ID_D) on delete restrict on update restrict;

alter table RESERVA add constraint FK_P__R1 foreign key (ID_P)
      references PACIENTE (ID_P) on delete restrict on update restrict;

