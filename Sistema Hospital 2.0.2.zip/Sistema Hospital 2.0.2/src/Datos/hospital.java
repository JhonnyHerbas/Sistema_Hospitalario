
package Datos;

import Logica.Administrador;
import Logica.Doctor;
import Logica.Paciente;
import Logica.Usuario;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class hospital {
    private static hospital instance =  null;
    private Map<String, Paciente> pacientes;
    private Map<String, Doctor> doctores;
    private Map<String, Administrador> adm;
    private Map<String, Usuario> usuarios;
    
    private  hospital()
    {
        pacientes = new HashMap<String, Paciente>();
        doctores = new HashMap<String, Doctor>();
        adm = new HashMap<String, Administrador>();
        usuarios = new HashMap<String, Usuario>();
    }
    public hospital getInstance(){
        if(instance == null)
        {
            instance = new hospital();
        }
        return instance;
    }
    public void addpaciente(Paciente a) throws Exception
    {
        Paciente p = pacientes.get(a.getCi());
        if(p == null)
        {
            pacientes.put(a.getCi(), a);
        }
        else
        {
            throw new Exception("Paciente ya existe");
        }
        
    }
     public void adddoctor(Doctor a) throws Exception
    {
        Doctor d = doctores.get(a.getCi());
        if(d == null)
        {
            doctores.put(a.getCi(), a);
        }
        else
        {
            throw new Exception("Doctor ya existe");
        }
        
    }
     public List<Paciente> getPacientes()
     {
         
         List<Paciente> li = new ArrayList<>();
         for (Map.Entry<String, Paciente> entry : pacientes.entrySet()) {
          li.add(entry.getValue());
             
         }
         return li;
         
     }
       public List<Doctor> getdoctores()
     {
         
         List<Doctor> li = new ArrayList<>();
         for (Map.Entry<String, Doctor> entry : doctores.entrySet()) {
          li.add(entry.getValue());
             
         }
         return li;
         
     }
       public List<Paciente> getPacienteci(String ci) throws Exception
       {
           List<Paciente> li = new ArrayList<>();
           Paciente p = pacientes.get(ci);
           if(p!=null)
           {
               li.add(p);
               return li;
           }
           else
           {
               throw new Exception("Paciente no existe");
           }
       }
        public List<Doctor> getDoctorci(String ci) throws Exception
       {
           List<Doctor> li = new ArrayList<>();
           Doctor d = doctores.get(ci);
           if(d!=null)
           {
               li.add(d);
               return li;
           }
           else
           {
               throw new Exception("Doctor no existe");
           }
       }
}
