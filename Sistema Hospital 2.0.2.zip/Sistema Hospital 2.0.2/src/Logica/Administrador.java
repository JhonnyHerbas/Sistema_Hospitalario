
package Logica;

public class Administrador {
    
}
