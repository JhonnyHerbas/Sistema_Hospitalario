/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ventanas;

/**
 *
 * @author Usuario
 */
public class PacienteO {
    int id;
    String nombre;
    String apellido;
    String sintomas;
    int afiliado;
    int num_Cel;
    String genero;
    int ci;
    int edad;

    public PacienteO(int id, String nombre, String apellido, String sintomas, int afiliado, int num_Cel, String genero,int ci, int edad) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.sintomas = sintomas;
        this.afiliado = afiliado;
        this.num_Cel = num_Cel;
        this.genero = genero;
        this.ci = ci;
        this.edad = edad;
    }

    PacienteO(int id, String text, String text0, String sintomas, int m, int parseInt, String text1, int parseInt0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCi() {
        return ci;
    }

    public void setCi(int ci) {
        this.ci = ci;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getSintomas() {
        return sintomas;
    }

    public void setSintomas(String sintomas) {
        this.sintomas = sintomas;
    }

    public int getAfiliado() {
        return afiliado;
    }

    public void setAfiliado(int afiliado) {
        this.afiliado = afiliado;
    }

    public int getNum_Cel() {
        return num_Cel;
    }

    public void setNum_Cel(int num_Cel) {
        this.num_Cel = num_Cel;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    
}
