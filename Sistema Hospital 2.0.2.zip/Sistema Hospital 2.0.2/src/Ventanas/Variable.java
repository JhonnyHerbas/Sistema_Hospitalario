/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ventanas;

/**
 *
 * @author Usuario
 */
public class Variable {
    String usuario = null;
    String contrasenia = null;
    int id = 0;

    public Variable(String usuario, String contrasenia,int id) {
        this.usuario = usuario;
        this.contrasenia = contrasenia;
        this.id=id;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }
    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id = id;
    }
    
}
