/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ventanas;

/**
 *
 * @author Usuario
 */
public class KardexO {
    String diagnostico;
    String cama;
    String grado;
    String dieta;
    String tratamiento;
    int idK;
    int idD;
    int idP;
    String peso;
    String altura;

    public KardexO(String text, String text0, String t, String die, String text1, int id, int id0, String parseInt, String parseInt0) {
        this.diagnostico = text;
        this.cama = text0;
        this.grado = t;
        this.dieta = die;
        this.tratamiento = text1;
        this.idD = id;
        this.idP = id0;
        this.peso = parseInt;
        this.altura = parseInt0;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

    public String getCama() {
        return cama;
    }

    public void setCama(String cama) {
        this.cama = cama;
    }

    public String getGrado() {
        return grado;
    }

    public void setGrado(String grado) {
        this.grado = grado;
    }

    public String getDieta() {
        return dieta;
    }

    public void setDieta(String dieta) {
        this.dieta = dieta;
    }

    public String getTratamiento() {
        return tratamiento;
    }

    public void setTratamiento(String tratamiento) {
        this.tratamiento = tratamiento;
    }

    public int getIdK() {
        return idK;
    }

    public void setIdK(int idK) {
        this.idK = idK;
    }

    public int getIdD() {
        return idD;
    }

    public void setIdD(int idD) {
        this.idD = idD;
    }

    public int getIdP() {
        return idP;
    }

    public void setIdP(int idP) {
        this.idP = idP;
    }

    public String getPeso() {
        return peso;
    }

    public void setPeso(String  peso) {
        this.peso = peso;
    }

    public String getAltura() {
        return altura;
    }

    public void setAltura(String altura) {
        this.altura = altura;
    }
    
}
