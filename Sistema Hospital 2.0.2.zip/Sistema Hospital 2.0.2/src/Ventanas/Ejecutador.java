
package Ventanas;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;


public class Ejecutador {
    
    static Connection con = null;
    static ResultSet resultado;
    static Statement sentencia;

    
            
    public Ejecutador() {
        try {
            //org.gjt.mm.mysql.Driver
            Class.forName("org.gjt.mm.mysql.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","");

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ejecutador.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("error 1");
        } catch (SQLException ex) {
            Logger.getLogger(Ejecutador.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("error 2");
        }
        
    }
    
    public void iniciar() throws FileNotFoundException, IOException{
        File file = new File("./src/sql/Hospital.sql"); 
  
        BufferedReader br = new BufferedReader(new FileReader(file)); 

        String st; 
        String comando = "";
        while ((st = br.readLine()) != null) {
          //System.out.println(st); 
          if(st.contains(";")){
            comando  =  comando + st;
            System.out.println("COMANDO---------------------------");
            System.out.println(comando); 
            //crear un metodo para ejecutar comando
            ejecutarCcmando(comando);
            comando = "";
          }else{
              comando  =  comando + st;
          }
        } 
    }
    public static void main(String [] args) throws IOException{
        new Ejecutador().iniciar();
    }

    private void ejecutarCcmando(String comando) {
        try {
            sentencia = con.createStatement();
            sentencia.execute(comando);
            sentencia.close();
            //con.close();
        } catch(Exception e){ System.out.println(e);
            System.out.println("Hay error al ejecutar comando");
        }
    }

    
    
   
    //para el Administrador
    
    public static Variable buscarUsuAd(String usu){
        Variable r = null;
        String q = "SELECT * FROM administrador WHERE USUARIO_A ='" + usu + "'";
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","");
            sentencia = con.createStatement();
            resultado = sentencia.executeQuery(q);
            System.out.println("correcto");
        } catch (SQLException ex) {
            Logger.getLogger(Ejecutador.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("ERROR");
        }
        r = asignar();
        return r;
    }
    private static Variable asignar() {
        Variable r = null;
        String usua;
        String caontra;
        int ids;
        try {
            if(resultado.first()){
                usua = resultado.getString("USUARIO_A");
                caontra = resultado.getString("CONTRASENIA");
                ids = resultado.getInt("ID_A");
                System.out.println("usurio: "+usua);
                System.out.println("pass: "+caontra);
                r = new Variable(usua,caontra,ids);
            }
        } catch (Exception e) {
            System.out.println("error1");
        }
        return r;
    }
    
    
    
    
    
    //para el Doctor:
    
    public static Doctor buscarContraDoc(String contra){
        Doctor r = null;
        String q = "SELECT * FROM doctor WHERE CONTRASENIA_D ='" + contra + "'";
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","");
            sentencia = con.createStatement();
            resultado = sentencia.executeQuery(q);
            System.out.println("correcto");
        } catch (SQLException ex) {
            Logger.getLogger(Ejecutador.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("ERROR");
        }
        r = asignarD();
        return r;
    }
    private static Doctor asignarD() {
        Doctor r = null;
        String usua;
        String caontra;
        int ids;
        String nombre;
        String apellido;
        String turno;
        String especialidad;
        String genero;
        int telefono;
        try {
            if(resultado.first()){
                nombre = resultado.getString("NOMBRE_D");
                apellido = resultado.getString("APELLIDO_D");
                especialidad = resultado.getString("ESPECIALIDAD"); 
                turno = resultado.getString("TURNO");
                telefono = resultado.getInt("TELEFONO");
                genero = resultado.getString("GENERO_D");
                usua = resultado.getString("USUARIO_D");
                caontra = resultado.getString("CONTRASENIA_D");
                ids = resultado.getInt("ID_D");
               
                r = new Doctor(ids,nombre,apellido,especialidad,caontra,usua,turno,telefono,genero);
            }
        } catch (Exception e) {
            System.out.println("error1");
        }
        return r;
    }
    
    
    
    //ID PACIENTE
    
    public static PacienteO buscarIdPa(String contra){
        PacienteO r = null;
        String q = "SELECT * FROM paciente WHERE CI_P ='" + contra + "'";
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","");
            sentencia = con.createStatement();
            resultado = sentencia.executeQuery(q);
            System.out.println("correcto");
        } catch (SQLException ex) {
            Logger.getLogger(Ejecutador.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("ERROR");
        }
        r = asignarP();
        return r;
    }
    
    
    
    
    
    
    
    
    
    //para el Paciente;
    
    public static PacienteO buscarContraPa(String contra){
        PacienteO r = null;
        String q = "SELECT * FROM paciente WHERE NOMBRE_P = '"+contra+"'";
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","");
            sentencia = con.createStatement();
            resultado = sentencia.executeQuery(q);
            System.out.println("correcto");
        } catch (SQLException ex) {
            Logger.getLogger(Ejecutador.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("ERROR");
        }
        r = asignarP();
        return r;
    }
    
    
    
    
    
    
    private static PacienteO asignarP() {
        PacienteO r = null;
        int edad;
        String sintomas;
        int ids;
        String nombre;
        String apellido;
        int afiliado;
        int numeroCel;
        String genero;
        int telefono;
        int ci;
        
        try {
            if(resultado.first()){
                nombre = resultado.getString("NOMBRE_P");
                apellido = resultado.getString("APELLIDO_P");
                System.out.println( resultado.getDate("FECHA_INGRESO")); 
                afiliado = resultado.getInt("AFILIADO");
                telefono = resultado.getInt("NUMEROCEL");
                genero = resultado.getString("GENERO_P");
                edad = resultado.getInt("EDAD");
                sintomas = resultado.getString("SINTOMAS");
                ids = resultado.getInt("ID_P");
                numeroCel = resultado.getInt("NUMEROCEL");
                ci = resultado.getInt("CI_P");
                
                r = new PacienteO(ids,nombre,apellido,sintomas,afiliado,numeroCel,genero,ci,edad);
            }
        } catch (Exception e) {
            System.out.println("error1");
        }
        return r;
    }
    
    
    
    
    public void InsertarPaaciente(PacienteO p){  
        PacienteO s = p; 
        try
        {
          con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","");
          // the mysql insert statement
          String query = " insert into paciente "
            + " values (?, ?, ? , ? , ? , ? , ? , ? , ? , ? , ? , ?)";

          // create the mysql insert preparedstatement
          PreparedStatement preparedStmt = con.prepareStatement(query);
          preparedStmt.setInt(1, s.getId());
          preparedStmt.setString(2, s.getNombre());
          preparedStmt.setString(3, s.getApellido());
          preparedStmt.setString(4, s.getSintomas());
          preparedStmt.setInt(5, s.getAfiliado());
          preparedStmt.setString(6,null);
          preparedStmt.setInt(7, s.getNum_Cel());
          preparedStmt.setString(8, s.getGenero());
          preparedStmt.setInt(9, s.getCi());
          preparedStmt.setInt(10, s.getEdad());
          preparedStmt.setString(11, null);
          preparedStmt.setString(12, null);
          
          // execute the preparedstatement
          preparedStmt.execute();

         con.close();
        }
        catch (Exception e)
        {
          System.err.println("Error guardar");
          System.err.println(e.getMessage());
        }
    }  
    
    
    
    
    
    public void InsertarKardex(KardexO p){  
        KardexO s = p; 
        try
        {
          con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","");
          // the mysql insert statement
          String query = " insert into kardex "
            + " values (?, ?, ? , ? , ? , ? , ? , ? , ? , ? , ? , ?)";

          // create the mysql insert preparedstatement
          PreparedStatement preparedStmt = con.prepareStatement(query);
          preparedStmt.setString(1, s.getDiagnostico());
          preparedStmt.setString(2, s.getCama());
          preparedStmt.setString(3, s.getGrado());
          preparedStmt.setString(4, null);
          preparedStmt.setString(5, s.getDieta());
          preparedStmt.setString(6, s.getTratamiento());
          preparedStmt.setString(7, null);
          preparedStmt.setInt(8, s.getIdD());
          preparedStmt.setInt(9, s.getIdP());
          preparedStmt.setString(10, s.getPeso());
          preparedStmt.setString(11, s.getAltura());
          preparedStmt.setString(12, null);
          
          // execute the preparedstatement
          preparedStmt.execute();

         con.close();
        }
        catch (Exception e)
        {
          System.err.println("Error guardar");
          System.err.println(e.getMessage());
        }
    }
    
    
    
    
    
    
    
    public void insertarDoctor(Doctor d){
        Doctor s = d;
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","");
            String query = "insert into doctor"
                    + " values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStmt = con.prepareStatement(query);
            preparedStmt.setInt(1, s.getId());
            preparedStmt.setString(2, s.getNombre());
            preparedStmt.setString(3, s.getApellido());
            preparedStmt.setString(4, s.getEspecialidad());
            preparedStmt.setString(5, s.getContrasenia());
            preparedStmt.setString(6, s.getUsuario());
            preparedStmt.setString(7, s.getTurno());
            preparedStmt.setInt(8, s.getTelefono());
            preparedStmt.setString(9, s.getGenero());
            
            preparedStmt.execute();
            con.close();
        } catch (Exception e) {
            System.err.println("Error guardar");
            System.err.println(e.getMessage());
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    //AUTO INCREMENTAR:
    
    public int incrementable() throws SQLException{
        int id = 1;
        PreparedStatement ps = null;
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","");
        sentencia = con.createStatement();
        
        try {
            ps = con.prepareStatement("SELECT MAX(ID_P) FROM paciente");
            resultado = ps.executeQuery();
            while(resultado.next()){
                id = resultado.getInt(1)+1;
            
            }
        } catch (Exception e) {
            System.out.println("error");
        }
        finally{
            try {
                ps.close();
            } catch (Exception e) {
            }
        }
        
        return id;
    }
    
    
    //doctor;
    public int incrementableD() throws SQLException{
        int id = 1;
        PreparedStatement ps = null;
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","");
        sentencia = con.createStatement();
        
        try {
            ps = con.prepareStatement("SELECT MAX(ID_D) FROM doctor");
            resultado = ps.executeQuery();
            while(resultado.next()){
                id = resultado.getInt(1)+1;
            
            }
        } catch (Exception e) {
            System.out.println("error");
        }
        finally{
            try {
                ps.close();
            } catch (Exception e) {
            }
        }
        
        return id;
    }
    
    
    
}
    
    
    

    
